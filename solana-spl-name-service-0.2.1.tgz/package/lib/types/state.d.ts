/// <reference types="node" />
import { Connection, PublicKey } from '@solana/web3.js';
import { Schema } from 'borsh';
type InitArgs = {
    parentName: Uint8Array;
    owner: Uint8Array;
    class: Uint8Array;
};
export declare class NameRegistryState {
    static HEADER_LEN: number;
    parentName: PublicKey;
    owner: PublicKey;
    class: PublicKey;
    data: Buffer | undefined;
    static schema: Schema;
    constructor(obj: InitArgs);
    static retrieve(connection: Connection, nameAccountKey: PublicKey): Promise<NameRegistryState>;
}
export {};
//# sourceMappingURL=state.d.ts.map